import java.math.BigDecimal;
import java.math.RoundingMode;

public class Site {
    public String name;
    public double rank;
    public double value;

    public Site(String name){
            this.rank = 0;
            this.name = name;

    }
    public void addRank(double r){
        this.rank = r;

    }

    public int compareTo (Site site){
       int result = this.name.compareTo(site.name);
       return result;
    }

    public boolean equals(Site site){
        if(compareTo(site) == 0 )
            return true;
        return false;
    }

    public String getName(){
        return this.name;
    }

    public double getRank(){
        return this.rank;
    }

    public int hasCode(){
        return this.hasCode();
    }

    public String toString (){
        BigDecimal bd = new BigDecimal(rank).setScale(5, RoundingMode.HALF_UP);

        return (this.name+"("+bd+")");
    }


}
