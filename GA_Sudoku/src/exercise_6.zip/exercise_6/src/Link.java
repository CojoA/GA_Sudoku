public class Link {
    protected String origin;
    protected String linked;

    public Link(String origin, String linked){
        this.origin = origin;
        this.linked = linked;
    }

    public boolean equals(Link link){
        if((link.origin.toLowerCase() == origin.toLowerCase()) && (link.linked.toLowerCase() == linked.toLowerCase()))
            return true;
        return false;
    }

    public String getLinked() {
        return linked;
    }
    public String getOrigin(){
        return origin;
    }

    public int hashCode(){
        return this.hashCode();
    }

    public String toString (){
        return linked+"->"+origin;
    }

}
