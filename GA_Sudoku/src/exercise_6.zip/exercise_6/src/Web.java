import java.util.*;

public class Web {
   private Set<Link> links;
   private double THRESHOLD;
   private Random alea;
   protected Set<Site> sites;

   public Web(){
       this.links = new HashSet<>();
       this.sites = new HashSet<>();
   }

   protected void addSite(Site site){
       sites.add(site);
   }
    protected void addSiteWithName(String name){
       Site siteNew = new Site(name);
       addSite(siteNew);
    }

    public void addLink(String dataLink){
       Scanner sc = new Scanner(dataLink);
       sc.useDelimiter("->");
       try {
           String newSite = sc.next();
           String newSite1 = sc.next();

           addSiteWithName(newSite);
           addSiteWithName(newSite1);
       }catch (IllegalArgumentException e){
           System.out.println("The datalink that caused the problems is: "+dataLink);
       }

    }

    public Site getSite(String name) {
        for (Site site : sites) {
            if (site.name == name)
                return site;
        }
            throw new NoSuchElementException("It does not exist in the sites");
    }
        public Set<String> getNames(){
       Set<String> names = new HashSet<>();
           for(Site site: sites){
               names.add(site.getName());
           }
           return names;
        }

    private Set<Site> getSitesLinkedFrom(Site page){

    }

}
